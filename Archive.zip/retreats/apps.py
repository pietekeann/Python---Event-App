from django.apps import AppConfig

class RetreatsConfig(AppConfig):
    name = 'retreats'
